#!/bin/bash
echo "=== Starting Fixed Debug Web UI ==="

# Add the fixed directory to Python path
export PYTHONPATH=/data/debug_web_ui_fixed:$PYTHONPATH

# Use real data (not mock)
export MOCK=false

# Copy build files from original location if needed
if [ ! -d "/data/debug_web_ui_fixed/build" ]; then
    echo "Copying build files from original location..."
    cp -r /etc/formlabs/alternatives/current/lib/formlabs/apps/diesel/debug_web_ui/build /data/debug_web_ui_fixed/
fi

cd /data/debug_web_ui_fixed
echo "Starting application on port 5001..."
python3 app_fixed.py --port 5001 --debug False
