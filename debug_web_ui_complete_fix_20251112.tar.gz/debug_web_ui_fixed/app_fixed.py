# MODIFICATIONS FROM ORIGINAL app.py:
# 1. Added eventlet monkey patch for async support
# 2. Changed import to use fixed MQTT listener
# 3. Set async_mode to 'eventlet'
# 4. Improved error handling and logging

# FIXED: Add eventlet monkey patch for async support
import eventlet
eventlet.monkey_patch()

from flask import Flask, request, render_template, send_from_directory
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from formlabs.platform import init_logging
from formlabs.task_engine.client import Leash
# MODIFIED: Import from fixed MQTT listener
from mqtt_listener_fixed import MqttListener
import argparse
import logging
import json
import math
import datetime
import time
import random
import base64
import os

p = None

use_mock = os.getenv("MOCK", "False").lower() in ("true", "1", "t")
if use_mock:
    from unittest.mock import MagicMock

    p = MagicMock()

    class MockProvider:
        def _get_data_at_time(self, time_ms):
            dt = datetime.datetime.fromtimestamp(time_ms / 1000.0, tz=datetime.timezone.utc)
            send_cpp_task_engine_format = True
            current_phase = "IDLE"
            if (time_ms / 1000) % 40 > 20:
                current_phase = "OVERSQUISH"
            def get_random_temp(offset=0):
                return 27000 + offset*300 + math.sin(time_ms / 1000) * 200
            if send_cpp_task_engine_format:
                return {
                    "mcu_broadcast": {
                        "force_and_position_readings": {
                            "phase": current_phase,
                            "xPosition": 10,
                            "zForce": 70980472,
                            "zForceTemp_mC": get_random_temp(),
                            "zPosition": 11
                        },
                        "thermistors_mC": [
                            get_random_temp(1),
                            get_random_temp(2),
                            get_random_temp(3),
                            get_random_temp(4),
                            get_random_temp(5),
                            get_random_temp(6)
                        ],
                        "IR_reading": 10
                    },
                    "hang_weight_N": 50.0,
                    "time": dt.strftime("%Y-%m-%dT%H:%M:%S.%f")
                }
            return {
                "dispenseStatus": {
                    "leftCartridgeWeight": -102851,
                    "rightCartridgeWeight": 784,
                },
                "forceAndPositionReadings": {
                    "zForce": -23.803673,
                    "zPosition": 249.06094,
                    "zForceTempMC": get_random_temp(-1),
                    "zForceRawN": -24.204767,
                    "xPosition": 244.99956,
                    "tUs": int(time_ms * 1000),
                    "xEnc": 244.8,
                    "zAxisState": "AXIS_STATE_IDLE",
                    "xAxisState": "AXIS_STATE_IDLE",
                    "phase": current_phase,
                },
                "ledStatus": {
                    "dutyCycle": 100.0,
                    "LEDTemepratureMC": 2,
                    "currentMA": 3,
                    "voltageMV": 4,
                },
                "lcdStatus": {"dutyCycle": 100.0, "currentMA": 3, "voltageMV": 4},
                "heaterStatus": {
                    "dutycycle": 100.0,
                    "heaterTemperatureMC": 2,
                    "resinTemperatureMC": 3,
                    "heaterCurrentMA": 4,
                    "heaterVoltageMV": 5,
                },
                "logList": {"logs": []},
                "sanicStatus": {
                    "timeSinceThisStateMCUMs": 289,
                    "timeSinceThisStateSanicMs": 50,
                    "distanceUm": 87605,
                    "temperatureMC": 21124,
                    "altTemperatureMC": 65535,
                    "ToFNs": 254909,
                    "ToFStdDevNs": 244,
                    "ToFSignalQuality": 12280,
                },
                "IRReading": get_random_temp(),
                "thermistors": [
                    get_random_temp(),
                    get_random_temp(),
                    get_random_temp(),
                    get_random_temp(),
                    get_random_temp(),
                    get_random_temp(),
                ],
                "hang_weight_N": 50,
                "time": dt.strftime("%Y-%m-%dT%H:%M:%S.%f"),
            }

        def load_data(self):
            end_time_ms = int(time.time() * 1000)
            step_size_ms = 100
            max_cached_values = 6000
            start_time_ms = end_time_ms - max_cached_values * step_size_ms
            return [self._get_data_at_time(t) for t in range(start_time_ms, end_time_ms, step_size_ms)]

        def get_last_data(self):
            return self._get_data_at_time(time.time() * 1000)


app = Flask(__name__, static_folder="build/static", template_folder="build")
app.config["SECRET_KEY"] = "secret!"
CORS(app, resources={r"/*": {"origins": "*"}})
# MODIFIED: Use async_mode='eventlet'
socketio = SocketIO(app, cors_allowed_origins="*", max_http_buffer_size=20971520, async_mode='eventlet')
streaming = False


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/favicon.ico")
def favicon():
    return send_from_directory("build", "favicon.ico")


@socketio.on("connect")
def connected():
    print("client has connected")
    emit("user-connect", {"sid": request.sid}, broadcast=True)


@socketio.on("startDataStreaming")
def start_data_streaming():
    global p
    global streaming
    if streaming:
        return
    streaming = True
    data = provider.get_last_data()
    if p is None:
        print("attempting to make leash connection")
        p = Leash()
        print("leash connected")
    while True:
        data = provider.get_last_data()
        emit(
            "dataPoint",
            {"data": data, "id": request.sid, "msgType": "forceAndPosition"},
            broadcast=True,
        )
        socketio.sleep(0.1)


@socketio.on("getAllData")
def getAllData():
    allData = provider.load_data()
    emit("AllData", {"data": allData})


@socketio.on("disconnect")
def disconnected():
    print("user disconnected")
    emit("user-disconnect", {"sid": request.sid}, broadcast=True)


@socketio.on("move_wiper")
def move_wiper(distance, velocity, acceleration):
    print(distance)
    print(velocity)
    print(acceleration)
    p.MCURelativeMove("X", float(distance), float(velocity), float(acceleration))
    print("wiper moving")
    emit("wiper moving")


@socketio.on("move_z")
def move_z(distance, velocity, acceleration):
    print("z moving")
    emit("z moving")
    if float(distance) > 0:
        p.MCUSet("Z", "Z_LIMIT_BEHAVIOR", 1)
    elif float(distance) < 0:
        p.MCUSet("Z", "Z_LIMIT_BEHAVIOR", 0)
    p.MCURelativeMove("Z", float(distance), float(velocity), float(acceleration))


@socketio.on("home_axes")
def home_axes():
    print("Homing Axes")
    p.RunSettingsFile("Homing.json")


@socketio.on("enable_z")
def enable_z(check_state):
    if check_state == True:
        p.EnableFeature("Z")
    else:
        p.DisableFeature("Z")


@socketio.on("enable_x")
def enable_x(check_state):
    if check_state == True:
        p.EnableFeature("X")
    else:
        p.DisableFeature("X")


@socketio.on("stop_expose")
def stop_expose():
    p.DisplayStopExposure()


@socketio.on("load")
def load(image):
    binary_image = base64.b64decode(image)
    with open("/tmp/uploaded_image.png", "wb") as image_file:
        image_file.write(binary_image)
    p.DisplayLoadImage("/tmp/uploaded_image.png")


@socketio.on("expose")
def expose(mode, duration_s):
    p.DisplayExposeImage(mode, float(duration_s), block=False)


@socketio.on("control_fan")
def control_fan(fan, duty_cycle):
    fan = fan.split("_")[0].upper()
    p.MCUSetFanDutyCycle(fan, float(duty_cycle))


@socketio.on("run_tasks")
def run_tasks(f_code):
    print(f_code)
    with open("/tmp/uploaded_f_code.json", "w") as f_code_file:
        f_code_file.write(f_code)
    p.RunTasks("/tmp/uploaded_f_code.json", block=False)


@socketio.on("dispense")
def dispense(dispense_duration_s):
    p.DispenserOpenValves(0, 30)
    print("duration:", dispense_duration_s)
    socketio.sleep(int(dispense_duration_s))
    p.DispenserCloseValves()


@socketio.on("disable_dispense")
def disable_dispense(checked):
    if checked:
        p.DisableFeature("dispenser")
    else:
        p.EnableFeature("dispenser")


@socketio.on("disable_heaters")
def disable_heaters(checked):
    if checked:
        p.HeaterShutoff()
        p.DisableFeature("heater")
    else:
        p.EnableFeature("heater")


@socketio.on("heater_shutoff")
def heater_shutoff():
    p.HeaterShutoff()


@socketio.on("heater_setpoint")
def heater_setpoint(setpoint):
    print("heater set to :", setpoint)
    p.LinuxInit()
    p.HeaterSetPoint(setpoint)


@socketio.on("heater_off")
def heater_off():
    p.HeaterShutoff()


@socketio.on("tare")
def tare():
    p.MCUTare()


@socketio.on("encoder_off")
def encoder_off(checked):
    if checked:
        p.MCUSet("x_encoder", enable=False)
    else:
        p.MCUSet("x_encoder", enable=True)


init_logging("debug_web_ui")
log = logging.getLogger("debug-web-ui")

if use_mock:
    print("Using MockProvider for testing")
    provider = MockProvider()
else:
    try:
        # MODIFIED: Use fixed MQTT listener
        print("Initializing Fixed MqttListener with task/end data...")
        provider = MqttListener()
        print("MqttListener initialized successfully - subscribed to task/end")
    except Exception as e:
        log.fatal("Failed to start provider\n{}".format(e))
        print("Falling back to MockProvider due to error:", e)
        provider = MockProvider()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default=5001, type=int, help="What port to host on")
    parser.add_argument('--debug', default=False, type=bool, help='If app should run in debug mode. Default = False')
    args = parser.parse_args()
    socketio.run(app, debug=args.debug, port=args.port, host="0.0.0.0", allow_unsafe_werkzeug=True)
