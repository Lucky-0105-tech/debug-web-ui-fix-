# MODIFICATIONS FROM ORIGINAL mqtt_listener.py:
# 1. Changed subscription from "mcu/status" to "task/end"
# 2. Added data filtering for MCUGetStatus tasks only
# 3. Added underscore field names for charts compatibility
# 4. Added automatic data flow trigger
# 5. Fixed time format for charts (ISO string)
# 6. Added safe type conversion for numeric values

import json
import threading
import subprocess
import time
import datetime
from collections import deque
import paho.mqtt.client as mqtt


class MqttListener:
    DEFAULT_HOST = "localhost"
    DEFAULT_SUB_PORT = 1883

    def __init__(
        self,
        host: str = DEFAULT_HOST,
        sub_port: int = DEFAULT_SUB_PORT,
        deqeue_size: int = 6000,
    ) -> None:
        self.host = host
        self.sub_port = sub_port
        self.data = deque(maxlen=deqeue_size)

        self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                       protocol=mqtt.MQTTv5)
        self.mqtt_client.connect(host, sub_port)
        self.mqtt_client.on_message = self._on_message
        
        # MODIFIED: Subscribe to task/end instead of mcu/status
        self.mqtt_client.subscribe("task/end", options=mqtt.SubscribeOptions(qos=1))
        print("MqttListener subscribed to: task/end")

        self._running = True
        threading.Thread(target=self._reader_thread, daemon=True).start()
        
        # NEW: Auto-start data flow trigger
        self._start_data_flow()

    def _format_mcu_data(self, mcu_info):
        """Format MCU data to match web UI expected format"""
        force_data = mcu_info.get('forceAndPositionReadings', {})
        
        # FIXED: Safely convert tUs to integer
        try:
            tUs = int(force_data.get('tUs', time.time() * 1000000))
        except (ValueError, TypeError):
            tUs = int(time.time() * 1000000)
        
        # FIXED: Convert timestamp to ISO string for charts
        try:
            dt = datetime.datetime.fromtimestamp(tUs / 1000000.0, tz=datetime.timezone.utc)
            iso_time = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
        except:
            iso_time = datetime.datetime.now(tz=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
        
        # FIXED: Safely convert all numeric values
        def safe_float(value, default=0):
            try:
                return float(value) if value is not None else default
            except (ValueError, TypeError):
                return default

        # Main data structure (for tables)
        formatted_data = {
            "dispenseStatus": {
                "leftCartridgeWeight": -102851,
                "rightCartridgeWeight": 784,
            },
            "forceAndPositionReadings": {
                "zForce": safe_float(force_data.get('zForce', 0)),
                "zPosition": safe_float(force_data.get('zPosition', 0)),
                "zForceTempMC": safe_float(force_data.get('zForceTempMC', 0)),
                "zForceRawN": safe_float(force_data.get('zForceRawN', 0)),
                "xPosition": safe_float(force_data.get('xPosition', 0)),
                "tUs": tUs,
                "xEnc": safe_float(force_data.get('xEnc', 0)),
                "zAxisState": force_data.get('zAxisState', 'AXIS_STATE_IDLE'),
                "xAxisState": force_data.get('xAxisState', 'AXIS_STATE_IDLE'),
                "phase": force_data.get('phase', 'IDLE'),
            },
            "ledStatus": {
                "dutyCycle": 100.0,
                "LEDTemepratureMC": safe_float(force_data.get('zForceTempMC', 0)),
                "currentMA": 3,
                "voltageMV": 4,
            },
            "lcdStatus": {"dutyCycle": 100.0, "currentMA": 3, "voltageMV": 4},
            "heaterStatus": mcu_info.get('heaterStatus', {
                "cartridgeHeaterDutyCycle": 0.0,
                "cartridgeHeaterCurrentMA": 0,
                "cartridgeHeaterVoltageMV": 0,
                "cartridgeTemperatureC": 25.0,
            }),
            "logList": {"logs": []},
            "sanicStatus": mcu_info.get('sanicStatus', {
                "timeSinceThisStateMCUMs": 289,
                "timeSinceThisStateSanicMs": 50,
                "distanceUm": 87605,
                "temperatureMC": 21124,
                "altTemperatureMC": 65535,
                "ToFNs": 254909,
                "ToFStdDevNs": 244,
                "ToFSignalQuality": 12280,
            }),
            "IRReading": safe_float(force_data.get('zForceTempMC', 0)),
            "thermistors": mcu_info.get('tempSensorsResinMC', [25000, 25100, 25200, 25300, 25400, 25500]),
            "hang_weight_N": 50,
            "time": iso_time,  # MODIFIED: ISO format for charts
        }
        
        # NEW: Add underscore version for charts compatibility
        formatted_data["force_and_position_readings"] = {
            "zForce": safe_float(force_data.get('zForce', 0)),
            "zPosition": safe_float(force_data.get('zPosition', 0)),
            "zForceTempMC": safe_float(force_data.get('zForceTempMC', 0)),
            "zForceRawN": safe_float(force_data.get('zForceRawN', 0)),
            "xPosition": safe_float(force_data.get('xPosition', 0)),
            "tUs": tUs,
            "xEnc": safe_float(force_data.get('xEnc', 0)),
            "zAxisState": force_data.get('zAxisState', 'AXIS_STATE_IDLE'),
            "xAxisState": force_data.get('xAxisState', 'AXIS_STATE_IDLE'),
            "phase": force_data.get('phase', 'IDLE'),
        }
        
        # NEW: Add mcu_broadcast structure for charts
        formatted_data["mcu_broadcast"] = {
            "force_and_position_readings": formatted_data["force_and_position_readings"],
            "thermistors_mC": formatted_data["thermistors"],
            "IR_reading": formatted_data["IRReading"]
        }
        
        return formatted_data

    def _on_message(self, client, userdata, msg):
        try:
            data = json.loads(msg.payload)
            
            # MODIFIED: Only process MCUGetStatus task results
            if (msg.topic == "task/end" and 
                data.get('task') == 'MCUGetStatus' and 
                'return_value' in data and 
                'info' in data['return_value']):
                
                mcu_info = data['return_value']['info']
                formatted_data = self._format_mcu_data(mcu_info)
                self.data.append(formatted_data)
                
                if len(self.data) % 10 == 0:
                    print(f"Data point #{len(self.data)} - Z Force: {formatted_data['forceAndPositionReadings']['zForce']:.2f}N")
                
            elif len(self.data) % 50 == 0:
                print(f"Received MQTT message on {msg.topic}: {data.get('task', 'unknown')}")
                
        except Exception as e:
            print(f"MQTT message processing error: {e}")

    def _start_data_flow(self):
        """Start automatic data flow trigger"""
        def data_trigger():
            print("MCU data flow trigger started - 2Hz frequency")
            count = 0
            try:
                while self._running:
                    result = subprocess.run(['leash', 'MCUGetStatus()'], 
                                          capture_output=True, text=True)
                    count += 1
                    if count % 20 == 0:
                        print(f"Triggered {count} MCU data updates")
                    time.sleep(0.5)
            except Exception as e:
                print(f"Data flow trigger error: {e}")
        
        threading.Thread(target=data_trigger, daemon=True).start()
        print("MCU data flow trigger started")

    @property
    def closed(self):
        return not self._running

    def _reader_thread(self) -> None:
        try:
            rc = 0
            while rc == 0:
                rc = self.mqtt_client.loop()
        finally:
            self.mqtt_client.disconnect()
            self._running = False

    def load_data(self):
        return list(self.data)

    def get_last_data(self):
        if len(self.data) > 0:
            return self.data[-1]
        return None
